#!/bin/bash

docker_original_image=$1
docker_image=$2
docker_image_tag=$3
docker_registry_host=cloud-docker-registry
docker_registry_http_port=4000
docker_registry=${docker_registry_host}:${docker_registry_http_port}

docker image tag ${docker_original_image} ${docker_registry}/${docker_image}:${docker_image_tag}
docker push ${docker_registry}/${docker_image}:${docker_image_tag}
