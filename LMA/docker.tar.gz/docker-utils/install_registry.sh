#!/bin/bash

docker run -d --name registry -p 4000:4000 --restart=always \
--env REGISTRY_HTTP_ADDR=0.0.0.0:4000 registry:2

apt-get install -y docker-compose
